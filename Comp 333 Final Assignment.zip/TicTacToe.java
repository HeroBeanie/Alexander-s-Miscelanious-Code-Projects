import java.util.*;

public class TicTacToe{
    private static final int none=0, player1=1,player2=2,playercpu=2,inprogress=0,
            tie=1, victoryplayer1=2, victoryplayer2=3,
            Row=3,Column=3;
    private static int currentplayer, currentrow,currentcolumn,currentprogress;
    private static int[][] board=new int[Row][Column];
    private static Scanner input = new Scanner(System.in);
    private static void mainMenue(int gameMode){
        startGame();
        if(gameMode==1)
            do{;
                cpuMove(currentplayer);
                printBoard();
                currentplayer =(currentplayer==player1)? playercpu:player1;

            }while(currentprogress==inprogress);

        if(gameMode==2)
            do{
                move(currentplayer);
                printBoard();
                checkGame(currentplayer,currentrow,currentcolumn);
                printResult(currentprogress);
                currentplayer =(currentplayer==player1)? player2:player1;

            }while(currentprogress==inprogress);
        if(gameMode==3)
            System.out.println("Thanks for Playing");

    }

    public static void main(String[] args) {
        System.out.println("1 player mode:1, 2 player mode:2, quit:3");
        int gameMode = input.nextInt();
        mainMenue(gameMode);
    }

    private static void startGame() {
        for(int row =0; row< Row; row++){
            for(int column =0;column<Column; column++){
                board[row][column]= none;
            }
        }
        currentprogress = inprogress;
        currentplayer = player1;
    }
    private static void move(int symbol) {
        boolean valid=false;
        do{
            if(symbol == player1){
                System.out.println("It is Player One's Turn, enter your move(# row then #column): ");
            }
            else{
                System.out.println("It is Player Two's Turn, enter your move(# row then #column): ");
            }
            int input1 = input.nextInt()-1;
            int input2 = input.nextInt()-1;
            if(0<= input1 && input1< Row && input2>= 0 && input2<Column && board[input1][input2] ==none){
                currentrow = input1;
                currentcolumn = input2;
                board[currentrow][currentcolumn] = symbol;
                valid = true;
            }
            else{
                System.out.println("That move is invalid Please enter another");
            }
        }while(!valid);

    }
    private static void cpuMove(int symbol){
        boolean valid=false;
        do{
            if(symbol == player1){
                System.out.println("It is Player One's Turn, enter your move(# row then #column): ");
                int input1 = input.nextInt()-1;
                int input2 = input.nextInt()-1;
                if(0<= input1 && input1< Row && input2>= 0 && input2<Column && board[input1][input2] ==none){
                    currentrow = input1;
                    currentcolumn = input2;
                    board[currentrow][currentcolumn] = symbol;
                    checkGame(symbol,currentrow,currentcolumn);
                    printResult(currentprogress);
                    valid = true;
                }
                else{
                    System.out.println("That move is invalid Please enter another");
                }
            }
            else{
                int input3= (int) (Math.random() * 3);
                int input4= (int) (Math.random() * 3);
                if(0<= input3 && input3< Row && input4>= 0 && input4<Column && board[input3][input4] ==none){
                    currentrow = input3;
                    currentcolumn = input4;
                    board[currentrow][currentcolumn] = symbol;
                    checkGame(symbol,currentrow,currentcolumn);
                    printResult(currentprogress);
                    valid=true;
                }
                else
                    System.out.println("That move is invalid Please enter another");

            }

        }while(!valid);

    }

    private static void checkGame(int symbol, int currentRow, int currentColumn) {
        if(isVictory(symbol, currentrow, currentcolumn))
            currentprogress= (symbol==player1)? victoryplayer1 : victoryplayer2;
        else
        if(isTie())
            currentprogress = tie;

    }
    private static boolean isTie() {
        for(int row =0; row< Row; row++){
            for(int column =0;column<Column; column++){
                if(board[row][column]==0)
                    return false;
            }
        }
        return true;
    }

    private static boolean isVictory(int symbol, int currentRow, int currentCol) {
        if((board[currentrow][0]==symbol && board[currentrow][1]==symbol && board[currentrow][2]==symbol)
                ||(board[0][currentcolumn]==symbol && board[1][currentcolumn]==symbol && board[2][currentcolumn]==symbol)
                ||(board[0][0]==symbol &&board[1][1]==symbol &&board[2][2]==symbol)
                ||(board[0][2]==symbol &&board[1][1]==symbol &&board[2][0]==symbol))
            return true;
        else
            return false;

    }
    private static void printBoard() {
        for(int row =0; row< Row; row++){
            for(int column =0;column<Column; column++){
                printSymbols(board[row][column]);
                if(column!=Column-1){
                    System.out.print("|");

                }
            }
            System.out.println();
            if(row!=Row-1){
                System.out.println("-----------");
            }
        }
        System.out.println();

    }
    private static void printSymbols(int placemarkers) {
        switch(placemarkers){
            case player1: System.out.print(" X ");
                break;
            case player2: System.out.print(" O ");
                break;
            case none: System.out.print("   ");
                break;
        }
    }
    private static void printResult(int gameStatus){
        if(currentprogress==victoryplayer1)
            System.out.println("Congratulations player 1 you have won!");
        if(currentprogress==victoryplayer2)
            System.out.println("Congratulations player 2 you have won!");
        if(currentprogress==tie)
            System.out.println("Too bad it is a tie, try again!");

    }



}            